package com.mfn.maku;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {
    EditText edit_pemasukan;
    Button button_tambah;
    SeekBar barBudget, barMakanan, barTransportasi, barLainnya;
    TextView budgetPersen, makananPersen, transportasiPersen, lainnyaPersen;


    Sqlite sqlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        sqlite = new Sqlite(this);
        edit_pemasukan            = findViewById(R.id.edit_pemasukan);
        barBudget();
        barMakanan();
        barTransportasi();
        barLainnya();
        button_tambah           = findViewById(R.id.button_tambah);


        button_tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit_pemasukan.getText().toString().equals("") && budgetPersen.getText().toString().equals("")
                        && makananPersen.getText().toString().equals("") && transportasiPersen.getText().toString().equals("")
                        && lainnyaPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Harap isi semua data" , Toast.LENGTH_LONG).show();
                } else if(edit_pemasukan.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Pemasukan  harus diisi ya" , Toast.LENGTH_LONG).show();
                    edit_pemasukan.requestFocus();
                }else if(budgetPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Budget harus diisi ya" , Toast.LENGTH_LONG).show();
                    budgetPersen.requestFocus();
                }
                else if(makananPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Makanan harus diisi ya" , Toast.LENGTH_LONG).show();
                    makananPersen.requestFocus();
                }else if(transportasiPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Transportasi harus diisi ya" , Toast.LENGTH_LONG).show();
                    transportasiPersen.requestFocus();
                }else if(lainnyaPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Lainnya harus diisi ya" , Toast.LENGTH_LONG).show();
                    lainnyaPersen.requestFocus();
                } else{
                    int makanan,transportasi,lainnya,jumlah;
                    makanan = Integer.parseInt(makananPersen.getText().toString());
                    transportasi = Integer.parseInt(transportasiPersen.getText().toString());
                    lainnya = Integer.parseInt(lainnyaPersen.getText().toString());

                    jumlah = (makanan + transportasi+lainnya);
//                    Log.e("_jumlahm", String.valueOf(makanan));
//                    Log.e("_jumlaht", String.valueOf(transportasi));
//                    Log.e("_jumlahl", String.valueOf(lainnya));
//                    Log.e("_jumlahj", String.valueOf(jumlah)); // cek jumlah sesuai atau tidak
                    if(jumlah != 100)
                    {
                        Toast.makeText(getApplicationContext(),"Tipe Pengeluaran harus berjumlah 100" , Toast.LENGTH_LONG).show();
                    }
                    else{
                        tambahData();
                    }

                }
            }
        });

        getSupportActionBar().setTitle("Atur Keuangan");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void barBudget( ) {
        barBudget = findViewById(R.id.barBudget);
        budgetPersen = findViewById(R.id.budgetPersen);
        budgetPersen.setText(barBudget.getProgress()+"");
        barBudget.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        budgetPersen.setText(barBudget.getProgress() +"");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        budgetPersen.setText(barBudget.getProgress()+"");
                    }
                }
        );
    }

    public void barMakanan( ) {
        barMakanan = findViewById(R.id.barMakanan);
        makananPersen = findViewById(R.id.makananPersen);
        makananPersen.setText(barMakanan.getProgress() + "" );
        barMakanan.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        makananPersen.setText(barMakanan.getProgress() + "" );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        makananPersen.setText(barMakanan.getProgress() + "" );
                    }
                }
        );
    }

    public void barTransportasi( ) {
        barTransportasi = findViewById(R.id.barTransportasi);
        transportasiPersen = findViewById(R.id.transportasiPersen);
        transportasiPersen.setText(barTransportasi.getProgress() + "" );
        barTransportasi.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        transportasiPersen.setText(barTransportasi.getProgress() + "" );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        transportasiPersen.setText(barTransportasi.getProgress() + "" );
                    }
                }
        );
    }

    public void barLainnya( ) {
        barLainnya = findViewById(R.id.barLainnya);
        lainnyaPersen = findViewById(R.id.lainnyaPersen);
        lainnyaPersen.setText(barLainnya.getProgress() + "" );
        barLainnya.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        lainnyaPersen.setText(barLainnya.getProgress() + "" );
                        
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                       
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        lainnyaPersen.setText(barLainnya.getProgress() + "" );
                        
                    }
                }
        );
    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    private void tambahData(){
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.execSQL("INSERT INTO datakeuangan(pemasukan, budget,makanan,transportasi, lainnya) VALUES('" +
                edit_pemasukan.getText().toString() + "','" +
                budgetPersen.getText().toString() + "','" +
                makananPersen.getText().toString() + "','" +
                transportasiPersen.getText().toString() + "','" +
                lainnyaPersen.getText().toString() + "')");
        Toast.makeText(getApplicationContext(), "Data berhasil ditambahkan", Toast.LENGTH_LONG).show();
//        Log.e("_edit_pemasukan", edit_pemasukan.getText().toString());
//        Log.e("_budgetPersen", budgetPersen.getText().toString());
//        Log.e("_makananPersen", makananPersen.getText().toString());
//        Log.e("_transportasiPersen", transportasiPersen.getText().toString());
//        Log.e("_lainnyaPersen", lainnyaPersen.getText().toString());
        finish();
    }
}


