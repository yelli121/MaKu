package com.mfn.maku;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.regex.Pattern;

public class EditActivity extends AppCompatActivity {
    EditText edit_pemasukan, edit_tanggal;
    Button button_edit;
    SeekBar barBudget, barMakanan, barTransportasi, barLainnya;
    TextView budgetPersen, makananPersen, transportasiPersen, lainnyaPersen;
    String tanggal;

    Sqlite sqlite;
    Cursor cursor;
    DatePickerDialog datePickerDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        sqlite = new Sqlite(this);
        edit_pemasukan           = findViewById(R.id.edit_pemasukan);
        edit_tanggal            = findViewById(R.id.edit_tanggal);
        barBudget();
        barMakanan();
        barTransportasi();
        barLainnya();
        button_edit           = findViewById(R.id.button_edit);
        button_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edit_pemasukan.getText().toString().equals("") && budgetPersen.getText().toString().equals("")
                        && makananPersen.getText().toString().equals("") && transportasiPersen.getText().toString().equals("")
                        && lainnyaPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Harap isi semua data" , Toast.LENGTH_LONG).show();
                } else if(edit_pemasukan.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Pemasukan  harus diisi ya" , Toast.LENGTH_LONG).show();
                    edit_pemasukan.requestFocus();
                }else if(budgetPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Budget harus diisi ya" , Toast.LENGTH_LONG).show();
                    budgetPersen.requestFocus();
                }
                else if(makananPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Makanan harus diisi ya" , Toast.LENGTH_LONG).show();
                    makananPersen.requestFocus();
                }else if(transportasiPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Transportasi harus diisi ya" , Toast.LENGTH_LONG).show();
                    transportasiPersen.requestFocus();
                }else if(lainnyaPersen.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(),"Lainnya harus diisi ya" , Toast.LENGTH_LONG).show();
                    lainnyaPersen.requestFocus();
                } else{
                    int makanan,transportasi,lainnya,jumlah;
                    makanan = Integer.parseInt(makananPersen.getText().toString());
                    transportasi = Integer.parseInt(transportasiPersen.getText().toString());
                    lainnya = Integer.parseInt(lainnyaPersen.getText().toString());

                    jumlah = (makanan + transportasi+lainnya);
                    Log.e("_jumlahm", String.valueOf(makanan));
                    Log.e("_jumlaht", String.valueOf(transportasi));
                    Log.e("_jumlahl", String.valueOf(lainnya));
                    Log.e("_jumlahj", String.valueOf(jumlah)); // cek jumlah sesuai atau tidak
                    if(jumlah != 100)
                    {
                        Toast.makeText(getApplicationContext(),"Tipe Pengeluaran harus berjumlah 100" , Toast.LENGTH_LONG).show();
                    }
                    else{
                        editData();
                    }

                }
            }
        });

        SQLiteDatabase db = sqlite.getReadableDatabase();
        cursor  =  db.rawQuery(
                "SELECT *, strftime('%d/%m/%Y', tanggal) AS tgl FROM datakeuangan WHERE datakeuangan_id ='"+MainActivity.datakeuangan_id+"'"
                , null);
        cursor.moveToFirst();
        edit_pemasukan.setText(cursor.getString(1));
        barBudget.setProgress(cursor.getInt(2));
        budgetPersen.setText(cursor.getString(2));
        barMakanan.setProgress(cursor.getInt(3));
        makananPersen.setText(cursor.getString(3));
        barTransportasi.setProgress(cursor.getInt(4));
        transportasiPersen.setText(cursor.getString(4));
        barLainnya.setProgress(cursor.getInt(5));
        lainnyaPersen.setText(cursor.getString(5));
        tanggal = cursor.getString(6);
        edit_tanggal.setText(cursor.getString(7));
        edit_tanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerDialog = new DatePickerDialog(EditActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        NumberFormat numberFormat = new DecimalFormat("00");
                        tanggal = year + "-" + numberFormat.format(month+1)+ "-"+ numberFormat.format(dayOfMonth);
                        Log.e("_tanggal",tanggal);

                        edit_tanggal.setText(numberFormat.format(dayOfMonth)+"/"+ numberFormat.format(month+1)
                                + "/"+ year);

                    }
                }, TanggalSekarang.tahun, TanggalSekarang.bulan, TanggalSekarang.hari);
                datePickerDialog.show();
            }
        });
//        budgetPersen.setText("99");




        getSupportActionBar().setTitle("Edit Data");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void barBudget( ) {
        barBudget = findViewById(R.id.barBudget);
        budgetPersen = findViewById(R.id.budgetPersen);
        budgetPersen.setText(barBudget.getProgress()+"");
        barBudget.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        budgetPersen.setText(barBudget.getProgress() +"");
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        budgetPersen.setText(barBudget.getProgress()+"");
                    }
                }
        );
    }

    public void barMakanan( ) {
        barMakanan = findViewById(R.id.barMakanan);
        makananPersen = findViewById(R.id.makananPersen);
        makananPersen.setText(barMakanan.getProgress() + "" );
        barMakanan.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        makananPersen.setText(barMakanan.getProgress() + "" );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        makananPersen.setText(barMakanan.getProgress() + "" );
                    }
                }
        );
    }

    public void barTransportasi( ) {
        barTransportasi = findViewById(R.id.barTransportasi);
        transportasiPersen = findViewById(R.id.transportasiPersen);
        transportasiPersen.setText(barTransportasi.getProgress() + "" );
        barTransportasi.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {

                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        transportasiPersen.setText(barTransportasi.getProgress() + "" );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        transportasiPersen.setText(barTransportasi.getProgress() + "" );
                    }
                }
        );
    }

    public void barLainnya( ) {
        barLainnya = findViewById(R.id.barLainnya);
        lainnyaPersen = findViewById(R.id.lainnyaPersen);
        lainnyaPersen.setText(barLainnya.getProgress() + "" );
        barLainnya.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    int progress_value = 0;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        progress_value = progress;
                        lainnyaPersen.setText(barLainnya.getProgress() + "" );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        lainnyaPersen.setText(barLainnya.getProgress() + "" );
                    }
                }
        );
    }
    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    private void editData(){
//        SQLiteDatabase database = sqlite.getWritableDatabase();
//        database.execSQL("INSERT INTO transaksi (pemasukan, budget, makanan, transportasi,lainnya) VALUES(" +
//                "'"+ edit_pemasukan.getText().toString()+"', '"+ budgetPersen.getText().toString()+"','"+ makananPersen.getText().toString()+"','"+ transportasiPersen.getText().toString()+"', '"+ lainnyaPersen.getText().toString()+"')");
//        Toast.makeText(getApplicationContext(),"Data Berhasil ditambahkan berupa" + budgetPersen.getText().toString() , Toast.LENGTH_LONG).show();
//        finish();
        SQLiteDatabase database = sqlite.getWritableDatabase();
        database.execSQL("UPDATE datakeuangan SET "
                + "pemasukan='" + edit_pemasukan.getText().toString() +
                "',budget='" + budgetPersen.getText().toString() +
                "',makanan='" + makananPersen.getText().toString() +
                "',transportasi='" + transportasiPersen.getText().toString() +
                "',lainnya='" + lainnyaPersen.getText().toString() +
                "',tanggal='" + tanggal +
                "'WHERE datakeuangan_id='" + MainActivity.datakeuangan_id +"' ");
        Toast.makeText(getApplicationContext(), "Transaksi berhasil diubah", Toast.LENGTH_LONG).show();
        finish();
    }

}
