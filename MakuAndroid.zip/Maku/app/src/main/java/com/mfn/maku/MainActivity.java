package com.mfn.maku;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    ListView list_transaksi;
    ArrayList<HashMap<String,String>> arus_transaksi;

    TextView text_pemasukan, text_pengeluaran, text_saldo;


    Sqlite  sqlite;
    Cursor  cursor;

    public static String datakeuangan_id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AddActivity.class));

//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();

            }
        });
        text_pemasukan = findViewById(R.id.text_pemasukan);
        text_pengeluaran = findViewById(R.id.text_pengeluaran);
        text_saldo = findViewById(R.id.text_saldo);

        list_transaksi = findViewById(R.id.list_kas);
        arus_transaksi = new ArrayList<>();

        sqlite  = new Sqlite(this);
//        kasTotal();

    }



    @Override
    public void onResume(){
        super.onResume();
        kasAdapter();
    }

    private void kasAdapter(){
        NumberFormat uang = NumberFormat.getInstance(Locale.GERMANY);
        arus_transaksi.clear(); list_transaksi.setAdapter(null);
        SQLiteDatabase  db = sqlite.getReadableDatabase();
        cursor  =  db.rawQuery(
                "SELECT *, strftime('%d/%m/%Y', tanggal) AS tgl FROM datakeuangan ORDER BY datakeuangan_id DESC"
                , null);
        for (int i = 0 ; i< cursor.getCount(); i++) {
            cursor.moveToPosition(i);
            HashMap<String,String> map = new HashMap<>();
            map.put("datakeuangan_id",cursor.getString(0) );
            map.put("pemasukan",uang.format(cursor.getDouble(1)) );
            map.put("budget", //perhitugan pengeluranan = pemasukan * budget/100
                    uang.format(cursor.getDouble(1) * cursor.getDouble(2)/100));
            map.put("makanan", //makanan = pengeluaran *makanan/100
                    uang.format(cursor.getDouble(1) * cursor.getDouble(2)/100
                            * cursor.getDouble(3)/100));
            map.put("transportasi",
                    uang.format(cursor.getDouble(1) * cursor.getDouble(2)/100
                            * cursor.getDouble(4)/100));
            map.put("lainnya",
                    uang.format(cursor.getDouble(1) * cursor.getDouble(2)/100
                            * cursor.getDouble(5)/100));
            map.put("tanggal",cursor.getString(7) );
            arus_transaksi.add(map); //masukan ke array list
        }

        SimpleAdapter simpleAdapter = new SimpleAdapter(this, arus_transaksi, R.layout.list_data,
                new String[]{"datakeuangan_id","pemasukan","budget","makanan","transportasi","lainnya","tanggal"},  //ngambil string dari arus_transaksi
                new int[] {R.id.text_data_keuangan_id,R.id.text_pemasukan, R.id.text_pengeluaran, R.id.text_makanan,
                        R.id.text_transportasi, R.id.text_lainnya,R.id.text_tanggal }
        );//ngambil viewnya dari list_kas
        list_transaksi.setAdapter(simpleAdapter); //masukin ke viewnya
        list_transaksi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                datakeuangan_id = ((TextView)view.findViewById(R.id.text_data_keuangan_id)).getText().toString();
                Log.e("_datakeuangan_id", datakeuangan_id);

                listMenu();
            }
        });
        kasTotal();


    }

    private void kasTotal(){
        NumberFormat uang = NumberFormat.getInstance(Locale.GERMANY);

        SQLiteDatabase db = sqlite.getReadableDatabase();
        cursor  = db.rawQuery("SELECT SUM(pemasukan) as Pemasukan, "+
                "(SELECT SUM(pemasukan * budget/100) from datakeuangan ) AS Pengeluaran FROM datakeuangan"
                , null);
        cursor.moveToFirst();
        text_pemasukan.setText(uang.format(cursor.getDouble(0)));
        text_pengeluaran.setText(uang.format(cursor.getDouble(1)));
        text_saldo.setText(
                uang.format(cursor.getDouble(0) - cursor.getDouble(1))
                );

    }

    private void listMenu() {
        final Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.list_menu);
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);

        TextView text_edit = dialog.findViewById(R.id.text_edit);
        TextView text_hapus = dialog.findViewById(R.id.text_hapus);

        text_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                startActivity(new Intent(MainActivity.this, EditActivity.class));
            }
        });

        text_hapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                Hapus();
            }
        });

        dialog.show();
    }

    private void Hapus(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Konfirmasi Hapus");
        builder.setMessage("Bener Mau hapus data ini?");
        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

                SQLiteDatabase db = sqlite.getWritableDatabase();
                db.execSQL("DELETE FROM datakeuangan WHERE datakeuangan_id = '"+datakeuangan_id+"'");

                Toast.makeText(getApplicationContext(), "Data berhasil dihapus", Toast.LENGTH_LONG).show();
                kasAdapter();
            }
        });
        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
