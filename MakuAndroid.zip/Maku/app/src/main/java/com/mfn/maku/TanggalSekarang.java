package com.mfn.maku;

import java.util.Calendar;

public class TanggalSekarang {
    public static Calendar calendar     = Calendar.getInstance(); //memanggil fungsi calendar
    public static int tahun              = calendar.get(Calendar.YEAR);
    public static int bulan              = calendar.get(Calendar.MONTH);
    public static int hari               = calendar.get(Calendar.DAY_OF_MONTH);
}
